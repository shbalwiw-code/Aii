package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ocr_results")
data class OcrResult(
    @PrimaryKey val imageUri: String,
    val extractedText: String,
    val timestamp: Long = System.currentTimeMillis()
)
