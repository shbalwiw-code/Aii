package com.example.data

import android.content.Context
import android.net.Uri
import android.util.Log
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
    addOnCanceledListener { cont.cancel() }
}

data class ScannedImage(
    val uri: Uri,
    val name: String,
    val score: Int,
    val text: String
)

class ImageScanner(
    private val context: Context,
    private val ocrDao: OcrDao
) {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val synonyms = mapOf(
        "lungs" to setOf("respiration", "respiratory", "breathing"),
        "respiration" to setOf("lungs", "respiratory", "breathing"),
        "respiratory" to setOf("lungs", "respiration", "breathing"),
        "heart" to setOf("cardiovascular", "blood", "veins"),
        "brain" to setOf("nervous", "system", "neurons"),
        "math" to setOf("algebra", "calculus", "geometry", "equation"),
        "physics" to setOf("force", "motion", "energy", "velocity")
    )

    fun expandQuery(query: String): Set<String> {
        val tokens = query.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        val expanded = mutableSetOf<String>()
        expanded.addAll(tokens)
        for (token in tokens) {
            synonyms[token]?.let { expanded.addAll(it) }
        }
        return expanded
    }

    private fun calculateScore(queryTokens: Set<String>, text: String): Int {
        if (queryTokens.isEmpty() || text.isBlank()) return 0
        val textTokens = text.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()
        val textStr = text.lowercase()

        var matchCount = 0f
        for (q in queryTokens) {
            var bestScore = 0f
            if (textTokens.contains(q)) {
                bestScore = 1f
            } else {
                for (t in textTokens) {
                    if (t.startsWith(q)) {
                        bestScore = Math.max(bestScore, 0.9f)
                    } else if (t.contains(q)) {
                        bestScore = Math.max(bestScore, 0.7f)
                    }
                }
            }
            matchCount += bestScore
        }

        val exactMatchBonus = if (textStr.contains(queryTokens.joinToString(" "))) 0.2f else 0f
        
        val score = ((matchCount / queryTokens.size) + exactMatchBonus) * 100
        return score.toInt().coerceIn(0, 100)
    }

    suspend fun processImage(uri: Uri, queryTokens: Set<String>): ScannedImage? = withContext(Dispatchers.IO) {
        val uriStr = uri.toString()
        var text = ocrDao.getTextForImage(uriStr)
        
        if (text == null) {
            try {
                val inputImage = InputImage.fromFilePath(context, uri)
                val result = recognizer.process(inputImage).await()
                text = result.text
                if (!text.isNullOrBlank()) {
                    ocrDao.insertOcrResult(OcrResult(uriStr, text!!))
                }
            } catch (e: Exception) {
                Log.e("ImageScanner", "OCR failed for $uri", e)
                text = ""
            }
        }
        
        if (text.isNullOrBlank()) return@withContext null
        
        val score = calculateScore(queryTokens, text!!)
        return@withContext ScannedImage(uri, "", score, text!!)
    }
}

