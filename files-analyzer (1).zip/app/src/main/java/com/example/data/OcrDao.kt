package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface OcrDao {
    @Query("SELECT extractedText FROM ocr_results WHERE imageUri = :uri LIMIT 1")
    suspend fun getTextForImage(uri: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOcrResult(result: OcrResult)
    
    @Query("DELETE FROM ocr_results WHERE imageUri = :uri")
    suspend fun deleteResult(uri: String)
}
