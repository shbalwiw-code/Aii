package com.example.ui

import android.app.Application
import android.content.ContentUris
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.ImageScanner
import com.example.data.ScannedImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.net.Uri

data class AnalyzerState(
    val isScanning: Boolean = false,
    val query: String = "",
    val minConfidence: Int = 50,
    val resultLimit: Int = 50,
    val results: List<ScannedImage> = emptyList(),
    val scannedCount: Int = 0,
    val totalImages: Int = 0,
    val statusText: String = "Ready to search"
)

class AnalyzerViewModel(application: Application) : AndroidViewModel(application) {
    private val db = Room.databaseBuilder(application, AppDatabase::class.java, "ocr-db").build()
    private val scanner = ImageScanner(application, db.ocrDao())

    private val _state = MutableStateFlow(AnalyzerState())
    val state: StateFlow<AnalyzerState> = _state.asStateFlow()

    private var scanJob: Job? = null
    private val imageUris = mutableListOf<Pair<Uri, String>>()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            loadDeviceImages()
        }
    }

    private suspend fun loadDeviceImages() {
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED
        )
        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
        
        val context = getApplication<Application>()
        context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            null,
            null,
            sortOrder
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val name = cursor.getString(nameColumn)
                val contentUri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                imageUris.add(Pair(contentUri, name))
            }
        }
        _state.update { it.copy(totalImages = imageUris.size) }
    }

    fun updateQuery(q: String) {
        _state.update { it.copy(query = q) }
    }

    fun updateConfidence(conf: Int) {
        _state.update { it.copy(minConfidence = conf) }
    }

    fun updateLimit(limit: Int) {
        _state.update { it.copy(resultLimit = limit) }
    }

    fun startScan() {
        if (_state.value.isScanning) {
            stopScan()
            return
        }

        val query = _state.value.query
        if (query.isBlank()) return

        _state.update { 
            it.copy(
                isScanning = true, 
                results = emptyList(), 
                scannedCount = 0,
                statusText = "Starting scan..."
            ) 
        }

        scanJob = viewModelScope.launch(Dispatchers.IO) {
            val queryTokens = scanner.expandQuery(query)
            val limit = _state.value.resultLimit
            val minConf = _state.value.minConfidence
            var count = 0
            
            for ((uri, name) in imageUris) {
                if (!(_state.value.isScanning)) break // Check cancellation
                
                count++
                val result = scanner.processImage(uri, queryTokens)
                
                _state.update { s ->
                    val newStatus = "Scanning $count / ${s.totalImages}"
                    if (result != null && result.score >= minConf) {
                        val currentList = s.results.toMutableList()
                        // Insert and maintain top N
                        currentList.add(result.copy(name = name))
                        currentList.sortByDescending { it.score }
                        
                        val trimmed = if (currentList.size > limit) currentList.take(limit) else currentList
                        s.copy(scannedCount = count, results = trimmed, statusText = newStatus)
                    } else {
                        s.copy(scannedCount = count, statusText = newStatus)
                    }
                }
            }
            
            _state.update { it.copy(isScanning = false, statusText = "Scan complete") }
        }
    }

    fun stopScan() {
        scanJob?.cancel()
        _state.update { it.copy(isScanning = false, statusText = "Scan paused") }
    }

    fun removeFromResults(uri: Uri) {
        _state.update { s ->
            s.copy(results = s.results.filter { it.uri != uri })
        }
    }
}
