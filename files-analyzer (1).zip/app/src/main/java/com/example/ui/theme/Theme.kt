package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

val DuolingoGreen = Color(0xFF58CC02)
val DuolingoBlue = Color(0xFF1CB0F6)
val DuolingoPurple = Color(0xFFCE82FF)
val DuolingoOrange = Color(0xFFFF9600)
val DuolingoRed = Color(0xFFFF4B4B)
val DuolingoBackground = Color(0xFFFFFFFF)
val DuolingoSurface = Color(0xFFF7F7F7)

private val DarkColorScheme =
  darkColorScheme(
    primary = DuolingoGreen, 
    secondary = DuolingoBlue, 
    tertiary = DuolingoOrange,
    background = Color(0xFF131415),
    surface = Color(0xFF202224),
    error = DuolingoRed
  )

private val LightColorScheme =
  lightColorScheme(
    primary = DuolingoGreen,
    secondary = DuolingoBlue,
    tertiary = DuolingoOrange,
    background = DuolingoBackground,
    surface = DuolingoSurface,
    error = DuolingoRed
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
