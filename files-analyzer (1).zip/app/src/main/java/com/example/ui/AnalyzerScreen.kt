package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.data.ScannedImage
import com.example.ui.theme.DuolingoBlue
import com.example.ui.theme.DuolingoGreen
import com.example.ui.theme.DuolingoOrange
import com.example.ui.theme.DuolingoPurple

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzerScreen(viewModel: AnalyzerViewModel = viewModel()) {
    val state by viewModel.state.collectAsState()
    var selectedImage by remember { mutableStateOf<ScannedImage?>(null) }
    
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text("Files Analyzer", fontWeight = FontWeight.ExtraBold) 
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Bar
            OutlinedTextField(
                value = state.query,
                onValueChange = { viewModel.updateQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(24.dp),
                placeholder = { Text("Search exercises, notes...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = DuolingoPurple) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = DuolingoPurple,
                    unfocusedBorderColor = Color.LightGray,
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { 
                    focusManager.clearFocus()
                    viewModel.startScan() 
                })
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Min Match: ${state.minConfidence}%", style = MaterialTheme.typography.labelMedium)
                    Slider(
                        value = state.minConfidence.toFloat(),
                        onValueChange = { viewModel.updateConfidence(it.toInt()) },
                        valueRange = 10f..99f,
                        colors = SliderDefaults.colors(thumbColor = DuolingoBlue, activeTrackColor = DuolingoBlue)
                    )
                }
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Column(modifier = Modifier.weight(1f)) {
                    Text("Limit: ${state.resultLimit}", style = MaterialTheme.typography.labelMedium)
                    Slider(
                        value = state.resultLimit.toFloat(),
                        onValueChange = { viewModel.updateLimit(it.toInt()) },
                        valueRange = 10f..100f,
                        steps = 8,
                        colors = SliderDefaults.colors(thumbColor = DuolingoOrange, activeTrackColor = DuolingoOrange)
                    )
                }
                
                Spacer(modifier = Modifier.width(16.dp))
                
                // Play / Stop Button
                FloatingActionButton(
                    onClick = { 
                        focusManager.clearFocus()
                        viewModel.startScan() 
                    },
                    containerColor = if (state.isScanning) MaterialTheme.colorScheme.error else DuolingoGreen,
                    contentColor = Color.White,
                    shape = CircleShape
                ) {
                    AnimatedContent(targetState = state.isScanning) { scanning ->
                        if (scanning) {
                            Icon(Icons.Rounded.Stop, contentDescription = "Stop Search")
                        } else {
                            Icon(Icons.Rounded.Search, contentDescription = "Start Search")
                        }
                    }
                }
            }
            
            // Status Text
            Text(
                text = state.statusText,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelLarge,
                color = if (state.isScanning) DuolingoBlue else Color.Gray
            )
            
            // Grid
            if (state.results.isEmpty() && !state.isScanning && state.query.isNotBlank()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No results found. Try a different term.", color = Color.Gray)
                }
            } else if (state.results.isEmpty() && !state.isScanning) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ImageSearch, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color.LightGray)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Search your local images with AI", color = Color.Gray)
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(140.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.results) { item ->
                        ImageCard(
                            image = item, 
                            onClick = { selectedImage = item },
                            onRemove = { viewModel.removeFromResults(item.uri) }
                        )
                    }
                }
            }
        }
    }
    
    if (selectedImage != null) {
        ViewerScreen(
            image = selectedImage!!,
            onClose = { selectedImage = null },
            onRemove = { 
                viewModel.removeFromResults(selectedImage!!.uri)
                selectedImage = null
            }
        )
    }
}

@Composable
fun ImageCard(image: ScannedImage, onClick: () -> Unit, onRemove: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clickable { onClick() }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = image.uri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            
            // Score Badge
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("${image.score}%", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
            
            // Remove Button
            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .size(24.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}
